# Spider Robot v3.1 – Enterprise Architecture

## Executive Summary
Spider Robot v3.1 is an AMP (Asymmetric Multi-Processing) system on Milk-V Duo 256M:
- Linux core runs **Brain Daemon** and **Eye Service**
- FreeRTOS core runs **Muscle Runtime**
- All servos are driven via **PCA9685** to eliminate Linux PWM jitter
- DualEye display is driven via **SPI** in Linux userspace
- Control plane uses **JSON** over WebSocket; real-time plane uses **binary** PosePacket31 over **RPMsg/OpenAMP** with CRC-16.

## System Goals
- Deterministic motion execution
- Hard safety guarantees (clamp, estop, watchdog)
- Maintainable modular codebase
- Enterprise-grade documentation, testability, and clear ownership boundaries

## Core Decisions (Traceability)
- **PCA9685** chosen for 12 leg servos + scan servo (CH12) to avoid PWM jitter and simplify scaling.
- **RPMsg/OpenAMP** chosen for inter-core messaging (low latency, standardized, less DIY complexity).
- **JSON** chosen for UI/Remote: debugability and rapid iteration.
- **CRC-16/CCITT-FALSE** chosen for motion packets: widely used, simple, robust.
- **Cooperative TaskManager** in Brain: predictable policy execution without blocking.
- **Central ErrorHandler**: rate-limited fault reporting and safety-first escalation.

## Architecture Diagram
See `DIAGRAMS.md` and `architecture.png`.

## Safety Model
- Muscle clamps all servo targets to **500..2500 µs**.
- Brain sends heartbeat; Muscle enters HOLD if no valid packet within **250ms**.
- ESTOP overrides all tasks and forces safe state.
- Single servo authority: **Muscle only** writes PCA9685.

## Services
### Brain Daemon (Linux)
- WebSocket JSON ingress/egress (Remote v3 + Browser UI)
- TaskManager (cooperative)
- ErrorHandler (policy + recovery)
- Obstacle avoidance logic
- Sends Eye events (unix socket JSON)
- Sends PosePacket31 (RPMsg)

### Eye Service (Linux)
- DualEye GC9D01 driver via spidev
- Per-eye independent state & animation:
  - blink/wink, look, cross-eye, roll, angry/suspicious moods
- Controlled by Brain events (no direct remote coupling)

### Muscle Runtime (FreeRTOS)
- RPMsg receiver -> queue
- CRC check
- Clamp + interpolator (float/fixed q16)
- Watchdog safety
- PCA9685 I2C output

## Boot Demo + Wakepose
- Boot demo runs automatically:
  - Eyes animation timeline
  - Servo wakepose profile (default/combat/pushup/hello/dance)
- Boot demo aborts on manual input or emergency events.

