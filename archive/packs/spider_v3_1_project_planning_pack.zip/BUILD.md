# Build Guide (Milk-V Duo 256M, v3.1)

## 0) Goals
- Linux: Brain Daemon + Eye Service (C/C++)
- FreeRTOS: Muscle runtime (RPMsg receiver, motion, PCA9685)
- RPMsg/OpenAMP inter-core IPC

## 1) Prerequisites
- Milk-V Duo 256M v1.0
- PCA9685 connected via I2C (SDA/SCL, common GND)
- DualEye Display connected via SPI (MOSI/SCLK/DC + CS1/CS2 + RST1/2 + BL1/2)
- Power: separate servo power rail for PCA9685 V+

## 2) Linux side (Buildroot SDK V2)
1. Flash SDK V2 image to storage.
2. Boot and verify:
   - networking
   - filesystem write location for config/logs
3. Verify devices:
   - `/dev/spidev*` (SPI)
   - `/dev/i2c-*` (I2C)
   - RPMsg devices (`/dev/rpmsg*` or rpmsg_char)
4. If `/dev/spidev*` missing: enable SPI in DTS / kernel config and rebuild image.

## 3) C/C++ Build Layout
- Use CMake for Linux components:
  - `brain_daemon`
  - `eye_service`

Artifacts:
- `/usr/bin/brain_daemon`
- `/usr/bin/eye_service`

## 4) Autostart at boot
- Prefer Brain supervising Eye Service.
- Buildroot usually uses init scripts:
  - `/etc/init.d/S50brain_daemon` (starts brain; brain launches eye_service)

## 5) FreeRTOS (Muscle)
- Build using the Milk-V Duo SDK FreeRTOS project structure.
- Enable OpenAMP/RPMsg endpoint with name `rpmsg_motion`.
- Implement callback -> FreeRTOS queue.
- Motion task consumes PosePacket31.

## 6) Wiring / Electrical Checkpoints
- Servo rail sized for peak current (12 servos can spike high).
- Common GND between Duo, PCA9685 logic, and servo power.
- I2C pullups: check board/module; avoid double-strong pullups.

## 7) Bring-up Order (recommended)
1) Power & I2C: detect PCA9685
2) FreeRTOS: set one channel to mid (1500µs)
3) Linux: Eye display init (fill left/right)
4) RPMsg: send HOLD heartbeat from brain; validate muscle receives
5) Boot demo: eyes + wakepose

## 8) Minimum Acceptance
- Eye demo on boot
- Stable heartbeats, no random motion
- ESTOP stops motion immediately
- Obstacle event triggers eyes + motion reaction (stub ok)
