# Configuration (v3.1)

## 1) Core Safety Limits
- Servo output range (µs): **500..2500** (hard clamp on Muscle side)
- Heartbeat timeout: **250 ms** -> HOLD (and optionally SafePose)
- Eye render FPS: 20–30
- Eye animation tick: 100 Hz
- Brain update loop: 200–500 Hz (cooperative; no blocking)

## 2) PCA9685 Channel Allocation
- CH0..CH11: 12 leg servos
- CH12: Scan servo (LiDAR radar)
- CH13..CH15: reserved

## 3) Wake Pose Profiles
Wake poses are **profiles**, made of frames.
Each frame: target `servo_us[13]`, duration `t_ms`, flags.

WakePose IDs:
- default
- combat
- pushup
- hello
- dance

### Template (to be filled once mapping is final)
```json
{
  "wakepose_default": {
    "frames": [
      { "t_ms": 800, "servo_us": [1500,1500, ... 13 values ...], "interp": "fixed_q16" }
    ]
  }
}
```

## 4) Persistent Settings
Brain Daemon stores configuration in a small JSON file:
- default wakepose id
- eye defaults (backlight, auto/manual)
- motion defaults (mode, interp mode)
- scan profile

Suggested path:
- `/etc/spider/v3.1/config.json` (or `/data/spider/config.json`)

## 5) Feature Toggles
- enable_eye_service: true
- enable_scan: true
- enable_obstacle_avoidance: true
- enable_remote_ws: true
- enable_serial_ingest: optional
