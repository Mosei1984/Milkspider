# Deployment & Operations (v3.1)

## 1) Process Model
- `brain_daemon` is the primary service.
- `eye_service` is launched and supervised by brain daemon.
- FreeRTOS firmware runs on the RT core (muscle).

## 2) Logging
- Brain: logs to file with rotation (avoid filling flash).
- Muscle: minimal fault flags; optionally report via rpmsg_status.

## 3) Config
- Store config in a writable partition (e.g. /data).
- Default config shipped in /etc/spider/v3.1.

## 4) Updates
- Version both JSON and PosePacket.
- Keep older versions in separate folders:
  - v2 unchanged
  - v3.1 isolated

## 5) Field Diagnostics
- UI telemetry endpoint: last faults, last seq, heartbeat age, scan status.
- Eye “error face” on fatal faults.
