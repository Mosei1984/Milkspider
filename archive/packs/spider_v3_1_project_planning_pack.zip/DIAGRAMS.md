# Diagrams (v3.1)

## Mermaid – System Architecture

```mermaid
flowchart TB
  Remote[Remote v3 / Browser UI\nWebSocket JSON] --> Brain[Brain Daemon (Linux)\nTaskManager + ErrorHandler]
  Brain -->|Unix Socket JSON| Eyes[Eye Service (Linux)\nGC9D01 DualEye SPI\nRenderer + Animator]
  Brain -->|RPMsg/OpenAMP Binary\nPosePacket31 + CRC16| Muscle[Muscle Runtime (FreeRTOS)\nCRC + Clamp + Interp\nSafety Watchdog]
  Muscle -->|I2C| PCA[PCA9685\nCH0-CH11 Legs\nCH12 Scan\nCH13-15 Res]
  Brain -->|LiDAR Ingest| Avoid[Obstacle Avoidance Policy]
  Avoid --> Brain
  Brain -->|Telemetry JSON| Remote
```

## Mermaid – Boot Demo Timeline (High Level)

```mermaid
sequenceDiagram
  participant Init as Boot
  participant Brain as brain_daemon
  participant Eyes as eye_service
  participant Muscle as muscle_rtos
  Init->>Brain: start
  Brain->>Eyes: connect (unix socket)
  Brain->>Muscle: connect (rpmsg)
  Brain->>Eyes: boot demo events (wake, wink, look, angry)
  Brain->>Muscle: wakepose frames (PosePacket31)
  Note over Brain: abort demo on manual input
  Brain->>Eyes: mode=auto
  Brain->>Muscle: HOLD heartbeat
```
