# Directory Layout (v3.1)

```
/v3.1/
  /common/
    protocol_posepacket31.h
    crc16_ccitt_false.h/.c
    protocol_json.md (reference)
    versioning.h
    limits.h
    timebase.h

  /brain_linux/
    /brain_daemon/
      main.cpp
      task_manager.hpp/.cpp
      error_handler.hpp/.cpp
      ws_server.hpp/.cpp                # JSON websocket ingress/egress
      serial_ingest.hpp/.cpp            # optional
      ipc_muscle_rpmsg.hpp/.cpp         # PosePacket31 sender
      eye_client_unix.hpp/.cpp          # JSON event sender to eye_service
      lidar_ingest.hpp/.cpp             # sensor interface (UART/I2C)
      obstacle_avoidance.hpp/.cpp       # policy engine
      config_store.hpp/.cpp             # persist config (wakepose, params)
      telemetry.hpp/.cpp                # publish status to UI

    /eye_service/
      main.cpp
      gc9d01_dualeye_spi.hpp/.cpp       # spidev + gpio backend
      gpio/
        gpio_backend.hpp
        gpio_backend_wiringx.cpp
        gpio_backend_gpiod.cpp          # optional
      eye_renderer.hpp/.cpp             # 160x160 RGB565 per eye
      eye_animator.hpp/.cpp             # wink/blink/look/mood

  /muscle_rtos/
    app_main.c/.cpp
    rpmsg_motion_rx.c                   # callback -> queue
    motion_task.c                       # CRC + clamp + dispatch + watchdog
    motion_runtime/
      interpolator_float.c
      interpolator_q16.c
      limiter.c                         # slew-rate, clamp
    drivers/
      pca9685.c                         # I2C, setPWM, us->ticks
      i2c_hal.c                         # platform i2c HAL adapter
      time_hal.c                        # millis/ticks
    safety/
      failsafe.c                        # hold/safepose
      fault_flags.c

/remote/v3/
  web/                                 # browser UI
  protocol/                            # JSON schemas
```

Notes:
- **Linux never writes PCA9685**. Only FreeRTOS (Muscle) writes servo outputs.
- Brain Daemon uses JSON (WS) for UI and Unix socket to Eye Service.
- Brain -> Muscle uses RPMsg with binary PosePacket31 + CRC-16.
