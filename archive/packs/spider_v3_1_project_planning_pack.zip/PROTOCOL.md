# Protocol Specification (v3.1)

## 1) JSON Envelope (Remote/Browser <-> Brain, Brain -> Eyes/UI)

All JSON messages MUST follow this envelope:

```json
{
  "v": "3.1",
  "src": "remote.v3|browser|brain|eye_service",
  "dst": "brain|eye_service|ui",
  "ts_ms": 12345678,
  "type": "sys|motion|eyes|scan|telemetry|error",
  "msg": { }
}
```

Rules:
- `v` MUST be `"3.1"`.
- Brain Daemon is the single entry point for external messages.
- Brain Daemon validates and clamps all parameters before generating motion packets.

### 1.1 Remote/Browser -> Brain: Motion Commands
```json
{
  "v":"3.1",
  "type":"motion",
  "msg":{
    "mode":"legacy_prg|phase_engine|dynamic_gen",
    "cmd":"move|stop|estop",
    "vec":{"fwd":0.0,"strafe":0.0,"turn":0.0},
    "stride":1.00,
    "speed":0.80,
    "lift":0.60,
    "interp":"fixed_q16|float"
  }
}
```

Constraints (Brain clamps):
- vec components: -1.0 .. +1.0
- stride: 0.80 .. 1.60 (initial safe window; adjust after validation)
- speed: 0.00 .. 1.00
- lift: 0.00 .. 1.00

### 1.2 Brain -> Eye Service: Eye Events
```json
{
  "v":"3.1",
  "type":"eyes",
  "msg":{
    "cmd":"mode|mood|look|blink|wink|crosseyed|roll|backlight",
    "mode":"auto|manual",
    "mood":"neutral|angry|happy|sleepy|suspicious",
    "L":{"x":0.0,"y":0.0},
    "R":{"x":0.0,"y":0.0},
    "eye":"left|right|both",
    "bl":180
  }
}
```

Constraints:
- x,y: -1.0 .. +1.0
- backlight: 0..255

### 1.3 Brain -> Eye Service: Boot Demo Control
```json
{ "v":"3.1", "type":"sys", "msg":{ "cmd":"boot_demo", "wakepose":"default|combat|pushup|hello|dance" } }
```

### 1.4 Scan / Obstacle Events (Brain internal; UI optional)
```json
{
  "v":"3.1",
  "type":"scan",
  "msg":{
    "cmd":"scan_start|scan_stop|set_profile",
    "profile":{"min_deg":-60,"max_deg":60,"step_deg":3,"rate_hz":8},
    "obstacle":{"dir":"left|front|right","dist_mm":240,"severity":0.7}
  }
}
```

---

## 2) Binary Protocol (Brain -> Muscle via RPMsg/OpenAMP)

### 2.1 PosePacket31 (Little Endian)

- **Servos are µs directly**.
- **Muscle clamps to 500..2500 µs** ALWAYS when `CLAMP_ENABLE` is set (default: always set in v3.1).

```c
#pragma pack(push,1)
typedef struct {
  uint16_t magic;        // 0xB31A
  uint8_t  ver_major;    // 3
  uint8_t  ver_minor;    // 1
  uint32_t seq;          // monotonic
  uint32_t t_ms;         // time to reach target pose
  uint16_t flags;        // bitfield
  uint16_t servo_us[13]; // CH0..CH12 (12 legs + scan servo)
  uint16_t crc16;        // CRC-16/CCITT-FALSE over bytes [0..sizeof-3]
} PosePacket31;
#pragma pack(pop)
```

### 2.2 Flags (v3.1)
- bit0: ESTOP
- bit1: HOLD
- bit2: CLAMP_ENABLE (always on)
- bit3..4: INTERP_MODE (00=float, 01=fixed_q16)
- bit5: SCAN_ENABLE
- others reserved

### 2.3 CRC-16 (CCITT-FALSE)
- poly: 0x1021
- init: 0xFFFF
- refin/refout: false
- xorout: 0x0000

Muscle behavior:
- CRC fail => drop packet + set fault flag.
- heartbeat timeout (no valid packet for 250ms) => HOLD + fault flag.

---

## 3) IPC Endpoints

Recommended:
- `rpmsg_motion`: PosePacket31 and heartbeat packets (heartbeat may be HOLD with last pose)
- `rpmsg_status`: optional status replies (fault flags, last seq, etc.)

---

## 4) Versioning

- Any incompatible change increments `ver_minor` or `ver_major` accordingly.
- Brain MUST reject any JSON `v` not equal to `"3.1"` unless explicitly configured for compatibility mode.
