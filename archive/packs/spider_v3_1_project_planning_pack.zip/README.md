# Spider Robot v3.1 – Project Planning & Documentation Pack

This pack is intended to minimize build-time surprises by providing:
- A complete architecture & protocol specification
- Clear build/deployment steps for Milk-V Duo 256M (Linux + FreeRTOS)
- A test plan, risk register, and acceptance criteria
- Configuration templates (wake poses, limits, feature toggles)
- Diagrams (Mermaid + rendered PNG)

See:
- ARCHITECTURE.md
- PROTOCOL.md
- CONFIG.md
- BUILD.md
- TEST_PLAN.md
- RISK_REGISTER.md
- DEPLOYMENT.md
- DIRECTORY_LAYOUT.md
- DIAGRAMS.md
