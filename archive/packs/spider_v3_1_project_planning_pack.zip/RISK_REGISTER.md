# Risk Register (v3.1)

| ID | Risk | Impact | Likelihood | Mitigation | Verification |
|----|------|--------|------------|------------|-------------|
| R1 | SPI /dev/spidev missing | Blocks Eye Service | Medium | Enable SPI in DTS/SDK; verify /dev/spidev* | bring-up checklist |
| R2 | RPMsg device naming differs by image | Blocks Brain->Muscle | High | Detect devices at runtime; document dmesg checks | integration test |
| R3 | Servo power brownout | Random resets/jerks | High | Separate servo rail; big capacitor; common ground | stress test |
| R4 | Incorrect servo mapping causes mechanical crash | Severe | Medium | Named channels + conservative wakeposes; clamp 500..2500; slow ramp | mechanical test |
| R5 | I2C bus contention | Servo lag | Medium | Only Muscle owns PCA writes; scan servo uses same PCA | integration test |
| R6 | JSON flooding | UI sluggish | Low | Rate limit, queue bounds, drop policy | stress test |
| R7 | Eye service crash | Loss of UI | Medium | Brain supervises & restarts; error handler | system test |
| R8 | LiDAR timing + scan servo oscillation | Bad obstacle data | Medium | dwell at angles; trigger capture on settle | system test |
