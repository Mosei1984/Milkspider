# Test Plan (v3.1)

## 1) Unit/Module Tests
### CRC-16
- Known vector test: compute CRC over synthetic packet bytes; compare.
- Reject packet with modified byte.

### PosePacket Validation
- invalid magic/version rejected
- CRC fail rejected
- clamp behavior 499 -> 500, 2501 -> 2500

## 2) Integration Tests
### RPMsg channel
- Brain sends 10 packets, Muscle acks last_seq (if status channel enabled).
- Heartbeat dropout => HOLD within 250ms.

### PCA9685
- One channel moves from 1500->1600->1500 without jitter.
- All 13 channels can be updated at 50Hz command rate.

### DualEye Display
- Left eye color fill red, right eye green.
- Per-eye independent wink.
- Mood change to angry (lid/brow shape) visible.

## 3) System Tests
### Boot Demo
- Runs at boot consistently.
- Aborts on manual input.

### Manual Override
- Remote motion input cancels boot demo and takes control.
- Eyes follow manual commands (look/wink).

### Obstacle Avoidance (initial)
- Inject obstacle event:
  - front -> eyes angry + motion HOLD/STOP
  - left -> eyes look left + slight turn request

## 4) Stress Tests
- Remote spam: 100 JSON msgs/sec -> brain rate-limits and remains stable.
- RPMsg packet rate: 50Hz sustained for 5 minutes.
- Eye FPS: 30FPS sustained for 10 minutes.

## 5) Acceptance Criteria
- No unexpected servo motion on boot.
- ESTOP always overrides.
- No watchdog resets under normal operation.
- Clear fault reporting to UI.
