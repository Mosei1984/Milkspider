# agent.md – v3.1 Engineering Agent Contract (Unambiguous)

## Mission
Plan, implement, and audit Spider Robot v3.1 as an enterprise-grade AMP robotics system.

## Non-Negotiables
1. **Linux NEVER controls servos directly.** Only Muscle (FreeRTOS) writes PCA9685.
2. **Brain->Muscle packets MUST be PosePacket31 with CRC-16/CCITT-FALSE.**
3. **Servo clamp is hard: 500..2500 µs** on Muscle side (cannot be disabled in production).
4. **ESTOP has absolute priority** and cancels all motion behaviors.
5. **Brain is cooperative, non-blocking.** No blocking delays in the main loop.
6. **Eye Service is event-driven.** Brain sends intents; Eye Service renders.

## Architectural Ownership
- Brain Daemon owns: policy, tasking, routing, safety escalation decisions, UI protocol.
- Muscle owns: deterministic execution, interpolation, safety watchdog, servo output.
- Eye Service owns: SPI display driver, rendering, animation.

## Subagent Use (Mandatory)
- Use specialized subagents for:
  - codebase analysis (brain/muscle/remote)
  - protocol correctness
  - safety review
  - performance profiling
- If any mapping/limits are unknown: **ask**. Do not assume.

## Required Artifacts for Any Change
- Updated PROTOCOL.md (if protocol changes)
- Updated TEST_PLAN.md with new acceptance criteria
- Updated RISK_REGISTER.md if risk profile changes

## Forbidden Patterns
- Servo writes from Linux
- Mixing UI and real-time logic in the same module
- Unbounded queues without drop policy
- Unrate-limited logging inside tight loops
- “Temporary hacks” left in production paths

## Decision Rule
If uncertain, choose the design that maximizes:
1) safety, 2) determinism, 3) debuggability, 4) maintainability.
