# Spider Robot v3.1 – Acceptance Checklist

## Boot & Safety
- [ ] No servo movement before Brain heartbeat starts
- [ ] Boot demo runs (eyes + wakepose)
- [ ] Boot demo aborts on manual input
- [ ] ESTOP immediately stops all motion

## Servo & Motion
- [ ] All servo outputs clamped to 500–2500 µs
- [ ] PCA9685 channels mapped correctly (CH0–11 legs, CH12 scan)
- [ ] Heartbeat timeout enters HOLD within 250 ms
- [ ] No jitter during steady pose

## Eye System
- [ ] Left/right eyes initialize independently
- [ ] Blink both / wink left / wink right works
- [ ] Look left/right/up/down works
- [ ] Angry / suspicious mood visible
- [ ] Eye reacts to obstacle events

## RPMsg / IPC
- [ ] PosePacket31 CRC validation works
- [ ] Invalid packets are ignored
- [ ] Sequence counter increments monotonically

## Obstacle Avoidance (Initial)
- [ ] Front obstacle triggers HOLD + angry eyes
- [ ] Left obstacle triggers look-left + turn hint
- [ ] Right obstacle triggers look-right + turn hint

## Stability
- [ ] Remote spam does not crash Brain
- [ ] Eye service crash is detected and restarted
- [ ] No memory leaks after 10 min run
