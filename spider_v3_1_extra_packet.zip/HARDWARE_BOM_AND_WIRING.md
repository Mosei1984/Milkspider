# Spider Robot v3.1 – Hardware BOM & Wiring Checklist

## Core Electronics
- Milk-V Duo 256M v1.0
- PCA9685 16-channel PWM Servo Driver
- DualEye 0.71" LCD Module (2× GC9D01, SPI)
- LiDAR sensor (UART or I2C, model-specific)
- 12× Servo motors (legs)
- 1× Servo motor (LiDAR scan)

## Power
- Separate servo power supply (sized for peak current of 12 servos)
- Logic power for Milk-V Duo
- Common ground between:
  - Milk-V Duo
  - PCA9685 logic GND
  - Servo power GND

## I2C Wiring (PCA9685)
- SDA -> Duo SDA
- SCL -> Duo SCL
- VCC (logic) -> 3.3V or 5V (module-dependent)
- V+ -> Servo power rail
- GND -> Common ground

Checklist:
- [ ] I2C address set correctly (default 0x40)
- [ ] Pull-ups verified (avoid double pull-ups)

## SPI Wiring (DualEye)
- MOSI -> Duo MOSI
- SCLK -> Duo SCLK
- DC -> GPIO
- CS1 -> GPIO (left eye)
- CS2 -> GPIO (right eye)
- RST1/RST2 -> GPIO (or tied if acceptable)
- BL1/BL2 -> GPIO or tied high

Checklist:
- [ ] SPI runs at stable clock (start 10–20 MHz)
- [ ] Display logic voltage compatible with Duo (3.3V preferred)

## LiDAR Scan Servo
- Connected to PCA9685 CH12
- Scan range configured conservatively initially

## Mechanical Safety
- [ ] First power-up with servos detached or horn removed
- [ ] Verify neutral (1500 µs) corresponds to safe pose
- [ ] Increase motion range gradually

## Final Pre-Power Checklist
- [ ] Correct polarity on all power rails
- [ ] Servo power not back-feeding logic rail
- [ ] Adequate decoupling capacitors near PCA9685
